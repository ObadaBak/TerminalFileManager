#ifndef PERMISSIONS_H
#define PERMISSIONS_H

// Changes the permissions of a file or folder
void change_permissions(const char *path, const char *mode_str);

#endif // PERMISSIONS_H

